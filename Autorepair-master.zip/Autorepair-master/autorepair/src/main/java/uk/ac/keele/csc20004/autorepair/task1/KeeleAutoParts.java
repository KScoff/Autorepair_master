

package uk.ac.keele.csc20004.autorepair.task1;

import uk.ac.keele.csc20004.autorepair.Autorepair;
import uk.ac.keele.csc20004.autorepair.Part;
import uk.ac.keele.csc20004.autorepair.ServiceRequest;

/** Complete the code relative to Task1 here.
 * Feel free to add more classes/interfaces if necessary.
 * 
 * Replace this comment with your own.
 *
 * @author Your Student ID here
 */
public class KeeleAutoParts implements Autorepair {
    // YOUR CODE HERE
    
    public static void main(String[] args) {
       
    }

    @Override
    public void placeRequest(ServiceRequest r) {
        // Delete the Exception and put your code here
        throw new UnsupportedOperationException("You need to implement this method as part of the coursework."); 
    }

    @Override
    public ServiceRequest getNextRequest() {
        // Delete the Exception and put your code here
        throw new UnsupportedOperationException("You need to implement this method as part of the coursework."); 
    }

    @Override
    public void completeService(ServiceRequest r) {
        // Delete the Exception and put your code here
        throw new UnsupportedOperationException("You need to implement this method as part of the coursework."); 
    }

    @Override
    public int getNumOfWaitingRequests() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Part fetchOilFilter() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Part fetchBattery() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Part fetchBrakes() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Part fetchTyres() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void refillOilFilter() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void refillBattery() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void refillBrakes() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void refillTyres() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getOilFilterStorageLevel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getBatteryStorageLevel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getBrakesStorageLevel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getTyresStorageLevel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
